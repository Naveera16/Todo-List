import React from "react";

const TodoCards = () => {
  return (
    <div class="card ">
      <div class="card-header">Genre name</div>
      <div class="card-body">
        <div className="row">
            <div className="col-md-1">
            {/* <i class="fa-solid fa-check"></i> */}
            <input
          class="form-check-input"
          type="checkbox"
          value=""
          id="flexCheckDefault"
        />
            </div>
            <div className="col-md-10">
       <div style={{ display: "inline-flex" }}>
          <h2 className="card-title">Title </h2>
          {/* <span className="ms-5" style={{ color: "grey" }}>
            Completed
          </span> */}
        </div>

        <p className="card-text mb-3">Description</p>
        <div style={{ color: "grey" }}>
          <span> date:11/june/2024</span>
          <span> </span>
        </div>
       </div>
            <div className="col-md-1">
            <i
            class="fa-solid fa-pen-to-square d-block mt-2 "
            style={{ color: "blue" }}
          ></i>
          <i
            class="fa-solid fa-trash d-block mt-3 "
            style={{ color: "red" }}
          ></i>
            </div>
        </div>
       
        

      
      </div>
    </div>
  );
};

export default TodoCards;
