import React from "react";
import { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Modal } from "bootstrap";
const Genre = () => {
  //--------------------------- Show Genre
  const [Genre, setGenre] = useState([]);
  useEffect(() => {
    // Function for fetching fgenre
    const fetchingGenre = async () => {
      try {
        const Response = await fetch(
          "https://66f2d22571c84d805876de7e.mockapi.io/genre"
        );
        if (Response.status === 200) {
          const fetchData = await Response.json();
          setGenre(fetchData);
        }
      } catch (error) {
        console.log(error);
      }
    };
    fetchingGenre();
  }, [Genre]);
  // ------------------------

  //----------------------- Add Genre
  const [Genrename, setGenrename] = useState("");
  const [Genrestatus, setGenrestatus] = useState("");
  const addGenre = async (e) => {
    e.preventDefault();
    if (Genrename.length > 0) {
      if (Genrestatus != "") {
        try {
          const Data = {
            name: Genrename,
            status: Genrestatus,
          };

          const Response = await fetch(
            "https://66f2d22571c84d805876de7e.mockapi.io/genre",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(Data),
            }
          );

          if (Response.status === 201) {
            const modalElement = document.getElementById("addgenre");
            const modal = Modal.getInstance(modalElement);
            modal.hide();
            toast.success(`${Genrename} Added in Genre`, {
              autoClose: 1000,
              theme: "dark",
            });
          }
        } catch (error) {
          toast.error(`Error ${error}`, {
            autoClose: 1000,
            theme: "dark",
          });
        }
      } else {
        // setError("Select Status!!");
        toast.error("Select Status!!", {
          autoClose: 1000,
          theme: "dark",
        });
      }
    } else {
      // setError("Name!!");
      toast.error("Enter Genre Name!!", {
        autoClose: 1000,
        theme: "dark",
      });
    }
  };
  //-----------------------

  //----------------------Delete genre
  const Deletegenre = async (id, Genre) => {
    try {
      const deleteGenre = await fetch(
        `https://66f2d22571c84d805876de7e.mockapi.io/genre/${id}`,
        { method: "DELETE" }
      );
      if (deleteGenre.status === 200) {
        Delete(Genre);
      } else {
        toast.error(`Error ${deleteGenre.statusText}`, {
          autoClose: 1000,
          theme: "dark",
        });
      }
    } catch (error) {
      toast.error(`Error ${error}`, {
        autoClose: 1000,
        theme: "dark",
      });
    }
  };
  // delete toast
  const Delete = (message) => {
    toast.success(`Genre ${message} deleted`, {
      autoClose: 1000,
      theme: "dark",
    });
  };
  //-----------------

  //---------------------- Update Genre states
  const [UpdateId, setUpdateId] = useState("");
  const [Updatename, setUpdatename] = useState("");
  const [Updatestatus, setUpdatestatus] = useState("");

  const Edit_genre = (id, name, status) => {
    setUpdateId(id);
    setUpdatename(name);
    setUpdatestatus(status);
    const modalElement = new Modal(document.getElementById("editModal"));
    modalElement.show();
  };
  const updateGenre = async (e) => {
    e.preventDefault();
    if (Updatename.length > 0) {
      if (Updatestatus != "") {
        try {
          const Data = {
            name: Updatename,
            status: Updatestatus,
          };

          const Response = await fetch(
            `https://66f2d22571c84d805876de7e.mockapi.io/genre/${UpdateId}`,
            {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(Data),
            }
          );

          if (Response.status === 200) {
            const modalElement = document.getElementById("editModal");
            const modal = Modal.getInstance(modalElement);
            modal.hide();
            toast.success("Genre Updated", {
              autoClose: 1000,
              theme: "dark",
            });
          }
        } catch (error) {
          toast.error(`Error ${error}`, {
            autoClose: 1000,
            theme: "dark",
          });
        }
      } else {
        // setError("Select Status!!");
        toast.error("Select Status!!", {
          autoClose: 1000,
          theme: "dark",
        });
      }
    } else {
      // setError("Name!!");
      toast.error("Enter Genre Name!!", {
        autoClose: 1000,
        theme: "dark",
      });
    }
  };
  //-------------------------------
  return (
    <>
      <div className="container mt-5">
        <div>
          <button
            className="btn btn-danger float-end "
            data-bs-toggle="modal"
            data-bs-target="#addgenre"
          >
            Add Genre
          </button>
          <h2 className="" style={{ color: "red" }}>
            Genre
          </h2>
        </div>
        <div className="mt-5">
          {Genre.map((data, index) => (
            <div class="card mb-3">
              <div class="card-body ">
               <div className="container">
               <div className="float-end ">
                  <button
                    onClick={() => Edit_genre(data.id, data.name, data.status)}
                    className="btn btn-primary d-block mt-2 p-1"
                  >
                    <i class="fa-solid fa-pen-to-square  "></i>
                  </button>
                  <button
                    className="btn btn-danger d-block mt-2 p-1"
                    onClick={() => Deletegenre(data.id, data.name)}
                  >
                    <i class="fa-solid fa-trash "></i>
                  </button>
                </div>
                <blockquote class="blockquote mb-0">
                  <p>{data.name}</p>
                  <footer class="blockquote-footer">
                    {" "}
                    <cite title="Source Title">{data.status}</cite>
                  </footer>
                </blockquote>
               </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div
        class="modal fade"
        id="addgenre"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <form onSubmit={addGenre}>
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                  Add Genre
                </h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div class="modal-body">
                <div className="container">
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">
                      Genre Name
                    </label>
                    <input
                      onChange={(e) => setGenrename(e.target.value)}
                      type="text"
                      class="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                  <div className="mb-3">
                    <label for="exampleInputEmail1" class="form-label">
                      Select Status
                    </label>
                    <select
                      onChange={(e) => setGenrestatus(e.target.value)}
                      class="form-control"
                      name=""
                      id=""
                    >
                      <option value="" selected>
                        Select Status{" "}
                      </option>
                      <option value="Active">Active</option>
                      <option value="InActive">Inactive</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  class="btn btn-primary"
                  data-bs-dismiss="modal"
                >
                  Add
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div
        class="modal fade"
        id="editModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <form onSubmit={updateGenre}>
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                  Update Genre
                </h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div class="modal-body">
                <div className="container">
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">
                      Genre Name
                    </label>
                    <input
                      onChange={(e) => setUpdatename(e.target.value)}
                      value={Updatename}
                      type="text"
                      class="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                  <div className="mb-3">
                    <label for="exampleInputEmail1" class="form-label">
                      Select Status
                    </label>
                    <select
                      onChange={(e) => setUpdatestatus(e.target.value)}
                      value={Updatestatus}
                      class="form-control"
                      name=""
                      id=""
                    >
                      <option value="" selected>
                        Select Status{" "}
                      </option>
                      <option value="Active">Active</option>
                      <option value="InActive">Inactive</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                  Update
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <ToastContainer />
    </>
  );
};

export default Genre;
